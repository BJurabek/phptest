<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo $page_title; ?></title>

    <link rel="stylesheet" type="text/css" href="/css/style.css" media="all">
    <link rel="icon" href="/css/ok.png" sizes="192x192">

</head>

<body>

    <div class="container">

