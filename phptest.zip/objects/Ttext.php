<?php
include_once 'objects/Validation.php';
class Ttext {

    private $conn;
    private $table_name = "ttexts";

    private $text_id;
    private $text_text;
    private $text_user_id;
    private $text_name;
    private $text_email;
    private $text_active;
    private $created_at;


    public function __construct($db) {
        $this->conn = $db;
    }


    public function sent($expres){

    $val = new Validation();

    if(isset($_COOKIE["id"]) && $_COOKIE["id"]==0){
    $val->name('email')->value($expres['email'])->required();
    $val->name('name')->value($expres['name'])->required();
    }

    $val->name('text')->value($expres['text'])->required();


    if(!$val->isSuccess()){
        echo $val->displayErrors();
    }


if(isset($_COOKIE["id"])){ $user_id = $_COOKIE["id"]; }else{ $user_id = NULL; }
if(isset($_COOKIE["user"])){ $name = $_COOKIE["user"]; }else{ $name = $this->html($expres['name']);}
if(isset($_COOKIE["email"])){ $email = $_COOKIE["email"]; }else{$email = $this->html($expres['email']); }
if(isset($_COOKIE["perm"])){ $perm = $_COOKIE["perm"]; }else{ $perm = 0; }


if(isset($expres["text"]) && isset($name) && isset($email)){
$data = ['text' => $this->html($expres["text"]),'user_id' => $user_id,'name' => $name,'email' => $email,'perm' => $perm,
    'created_at' => date("Y-m-d H:i")];


$sql = "INSERT INTO " . $this->table_name . " (text, user_id, name, email, perm, created_at) VALUES (:text, :user_id, :name, :email, :perm, :created_at)";
$stmt= $this->conn->prepare($sql);
$stmt->execute($data);

            return true;
}else{ return false;}

    }



 public function update($update){


if(empty($update['active'])){ $active = 0; }else{ $active = 1; }

        $query = "SELECT * FROM ".$this->table_name." WHERE id = '".$update['tid']."'";
        $user = $this->conn->prepare($query);
        $user->execute();
        $result = $user->fetch();
        $this->text = $result['text'];


if(isset($this->text) && $this->text == $update['text']){ $redak = 0; }else{ $redak = 1; }


$sql = "UPDATE ". $this->table_name . " SET text=?, active=?, redak=? WHERE id=?";
$stmt= $this->conn->prepare($sql);
$stmt->execute([$this->html($update['text']), $active, $redak, $update['tid']]);
        return true;
 }

  public function redirect(){
        $host  = $_SERVER['HTTP_HOST'];
        $uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
        header("Location: http://$host$uri/");
        exit;
    }

     public function filtr($filtr){
        if ($filtr==1) {setcookie("filtr", 'name ASC', time()+36000);$this->redirect();return true;}
        elseif ($filtr==2) {setcookie("filtr", 'name DESC', time()+36000);$this->redirect();return true;}
        elseif ($filtr==3) {setcookie("filtr", 'email ASC', time()+36000);$this->redirect();return true;}
        elseif ($filtr==4) {setcookie("filtr", 'email DESC', time()+36000);$this->redirect();return true;}
        elseif ($filtr==5) {setcookie("filtr", 'perm ASC', time()+36000);$this->redirect();return true;}
        elseif ($filtr==6) {setcookie("filtr", 'perm DESC', time()+36000);$this->redirect();return true;}
        else {return false;}
     }


        function readName() {

            $query = "SELECT name FROM " . $this->table_name . " WHERE id = ? limit 0,1";

            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(1, $this->id);
            $stmt->execute(array(':text'=>$text,':name'=>$name));

            $row = $stmt->fetch(PDO::FETCH_ASSOC);

            $this->name = $row['name'];
        }

        function readAll($from_record_num, $records_per_page) {

            if(isset($_COOKIE["filtr"])){ $filtr = $_COOKIE["filtr"]; }else{ $filtr = 'id';}


    $query = "SELECT * FROM " . $this->table_name . "
            ORDER BY " . $filtr . " LIMIT {$from_record_num}, {$records_per_page}";

    $stmt = $this->conn->prepare($query);
    $stmt->execute();

    return $stmt;
    }


public function countAll() {

    $query = "SELECT id FROM " . $this->table_name . "";

    $stmt = $this->conn->prepare( $query );
    $stmt->execute();

    $num = $stmt->rowCount();

    return $num;
    }

    public function html($exp){
        return htmlspecialchars(trim($exp),ENT_QUOTES,'UTF-8');
    }


}
?>