<?php

include_once 'objects/Validation.php';

class User {

    private $conn;
    private $table_name = "users";

    private $user_id;
    private $user_name;
    private $user_login;
    private $user_email;
    private $user_password;
    private $created_at;


    public function __construct($db) {
        $this->conn = $db;
    }



    public function login($user_login, $user_password) {
        // Фильтрация.
            $val = new Validation();

    $val->name('login')->value($expres['login'])->required();
    $val->name('password')->value($expres['password'])->required();

    if(!$val->isSuccess()){
        echo $val->displayErrors();
    }

        $this->user_login = $this->html($user_login);
        $this->user_password = md5(md5($user_password));

        $query = "SELECT * FROM ".$this->table_name." WHERE login = '".$this->user_login."' and password = '".$this->user_password."'";

        $user = $this->conn->prepare($query);
        $user->execute();

        $result = $user->fetch();

        $this->user_id = $result['id'];
        $this->user_name = $result['name'];
        $this->perm = $result['perm'];
        $this->email = $result['email'];

        if ($result) {
            setcookie("id", $this->user_id, time()+36000);
            setcookie("user", $this->user_name, time()+36000);
            setcookie("password", $this->user_password, time()+36000);
            setcookie("email", $this->email, time()+36000);
            setcookie("perm", $this->perm, time()+36000);
            $this->redirect();
            return true;
        } else {
            return false;
        }

    }




    public function logout() {
        setcookie("email", "");
        setcookie("perm", "");
        setcookie("user", "");
        setcookie("password", "");
        setcookie("id", "");
        $this->redirect();
        return true;
    }

  public function redirect(){
        $host  = $_SERVER['HTTP_HOST'];
        $uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
        header("Location: http://$host$uri/");
        exit;
    }


    public function register($expres){




    $val = new Validation();

    $val->name('login')->value($expres['login'])->required();
    $val->name('email')->value($expres['email'])->required();
    $val->name('name')->value($expres['name'])->required();

    $val->name('password')->value($expres['password'])->min(3)->max(8)->required();
    $val->name('password2')->value($expres['password2'])->min(3)->max(8)->required();
    $val->pass_check($expres['password'],$expres['password2']);



        if(!$val->isSuccess()){
        echo $val->displayErrors();
    }


    $query = "SELECT * FROM ".$this->table_name." WHERE login = '".$this->html($expres["login"])."' and email = '".$this->html($expres["email"])."'";
        $user = $this->conn->prepare($query);
        $user->execute();
        $result = $user->fetch();



        if (empty($result) && isset($expres["name"]) && isset($expres["email"]) && isset($expres["login"]) && isset($expres["password"]) && isset($expres["password2"]) && $expres["password"] === $expres["password2"] && $expres["email"] == $result["email"] && $expres["login"] == $result["login"]) {

        $this->password = md5(md5($expres["password"]));


$data = ['name' => $this->html($expres["name"]),'email' => $this->html($expres["email"]),'login' => $this->html($expres["login"]),'password' => $this->password,
    'created_at' => date("Y-m-d H:i")];
$sql = "INSERT INTO users (name, email, login, password, created_at) VALUES (:name, :email, :login, :password, :created_at)";
$stmt= $this->conn->prepare($sql);
$stmt->execute($data);
$this->user_id = $this->conn->lastInsertId();
// var_dump($this->user_id);

        $this->user_name = $expres["name"];
        $this->perm = 0;

            setcookie("id", $this->user_id, time()+36000);
            setcookie("user", $this->user_name, time()+36000);
            setcookie("password", $this->password, time()+36000);
            setcookie("perm", $this->perm, time()+36000);
            $this->redirect();
            return false;
        } else {
            echo 'Этот логин или пароль ужи пользователем';
        }


    }


    public function html($exp){
        return htmlspecialchars(trim($exp),ENT_QUOTES,'UTF-8');
    }


}
?>